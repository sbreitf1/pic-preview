How to build installer:

1. Download and install NSIS: http://nsis.sourceforge.net
2. Download and install XML Plugin: http://nsis.sourceforge.net/XML_plug-in
