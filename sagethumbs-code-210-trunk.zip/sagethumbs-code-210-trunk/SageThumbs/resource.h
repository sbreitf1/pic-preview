//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SageThumbs.rc
//
#define IDS_PROJNAME                    100
#define IDR_SAGETHUMBS                  101
#define IDS_OPTIONS_HELP                101
#define IDR_THUMB                       102
#define IDS_TYPE                        102
#define IDS_DIM                         103
#define IDS_SIZE                        104
#define IDS_DATE                        105
#define IDS_COLORS                      106
#define IDS_COMPRESSION                 107
#define IDS_RESOLUTION                  108
#define IDS_ERR_OPEN                    109
#define IDS_ERR_SAVE                    110
#define IDS_ERR_MAIL                    111
#define IDS_ERR_NOTHING                 112
#define IDS_ERR_CLIPBOARD               113
#define IDS_CLEAR_PROMPT                114
#define IDS_DATABASE_SIZE               115
#define IDS_CACHE                       116
#define IDS_DESCRIPTION                 117
#define IDS_ACCESS_DENIED               118
#define IDS_CONVERT_PNG                 119
#define IDS_CONVERTING                  120
#define IDS_SENDING                     121
#define IDS_APPLYING                    122
#define IDS_UPDATING                    123
#define IDC_WIDTH                       201
#define IDC_HEIGHT                      202
#define IDD_OPTIONS                     202
#define IDC_USE_FAX                     203
#define IDS_OPTIONS                     203
#define IDC_TYPES_LIST                  204
#define IDS_CLIPBOARD                   204
#define IDS_WALLPAPER_TILE              205
#define IDS_WALLPAPER_CENTER            206
#define IDC_COPYRIGHT                   206
#define IDS_WALLPAPER_STRETCH           207
#define IDC_LANG                        207
#define IDS_MAIL_IMAGE                  208
#define IDS_MAIL_THUMBNAIL              209
#define IDS_CONVERT_JPG                 210
#define IDC_SELECT                      210
#define IDS_CONVERT_GIF                 211
#define IDC_ENABLE_MENU                 211
#define IDS_CONVERT_BMP                 212
#define IDC_ENABLE_THUMBS               212
#define IDC_CLEAR                       213
#define IDC_FILE_SIZE                   214
#define IDC_EMBEDDED                    215
#define IDC_ENABLE_ICONS                216
#define IDC_ENABLE_WINCACHE             217
#define IDC_OPTIMIZE                    218
#define IDC_JPEG                        219
#define IDC_PNG                         220
#define IDC_JPEG_SPIN                   221
#define IDC_PNG_SPIN                    222
#define IDC_DEFAULT                     223
#define IDC_CACHE_SIZE                  224
#define IDC_ENABLE_OVERLAY              225
#define IDC_SUBMENU                     226
#define IDC_CUSTOM                      227

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        215
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         228
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
