/*
SageThumbs - Thumbnail image shell extension.

Copyright (C) Nikolay Raspopov, 2004-2014.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "stdafx.h"
#include "SageThumbs.h"
#include "Thumb.h"

// IPreviewHandler

//STDMETHODIMP CThumb::SetWindow(HWND hwnd, const RECT *prc)
//{
//	ATLTRACENOTIMPL( _T("IPreviewHandler::SetWindow") );
//}
//
//STDMETHODIMP CThumb::SetRect(const RECT *prc)
//{
//	ATLTRACENOTIMPL( _T("IPreviewHandler::SetRect") );
//}
//
//STDMETHODIMP CThumb::DoPreview(void)
//{
//	ATLTRACENOTIMPL( _T("IPreviewHandler::DoPreview") );
//}
//
//STDMETHODIMP CThumb::Unload(void)
//{
//	ATLTRACENOTIMPL( _T("IPreviewHandler::Unload") );
//}
//
//STDMETHODIMP CThumb::SetFocus(void)
//{
//	ATLTRACENOTIMPL( _T("IPreviewHandler::SetFocus") );
//}
//
//STDMETHODIMP CThumb::QueryFocus(HWND *phwnd)
//{
//	ATLTRACENOTIMPL( _T("IPreviewHandler::QueryFocus") );
//}
//
//STDMETHODIMP CThumb::TranslateAccelerator(MSG *pmsg)
//{
//	ATLTRACENOTIMPL( _T("IPreviewHandler::TranslateAccelerator") );
//}
